//
//  TableViewController.swift
//  ToDo
//
//  Created by Angelina on 22.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {

//    @IBAction func moveToToDoList(segue: UIStoryboardSegue){
//        guard segue.identifier == "listSegue" else {return}
//        guard let currentSource = segue.source as? ViewController else {return}
//    }
    
    var str: String?
//    var newTaskTitle: String?
//    var newTaskDescription: String?
//    var newTaskTag: String?
//    var newTaskDate: String?
    
    var tasks: [TaskToDo] = []
    
    override func viewWillAppear(_ animated: Bool) {
//        print("!!!")
//        print(newTaskTitle)
//        guard let newTaskTitle = newTaskTitle else {return}
//        print(newTaskTitle)
//        guard let newTaskDescription = newTaskDescription else {return}
//        print(newTaskDescription)
//        guard let newTaskTag = newTaskTag else {return}
//        print(newTaskTag)
//        guard let newTaskDate = newTaskDate else {return}
//        print(newTaskDate)
//        saveTask(titleToSave: newTaskTitle, descriptionToSave: newTaskDescription, timeToSave: newTaskDate, tagToSave: newTaskTag)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<TaskToDo> = TaskToDo.fetchRequest()
        do{
            tasks = try context.fetch(fetchRequest)
            print("saved")
        } catch {
            print("error")
        }
    }

    
    func saveTask( titleToSave: String, descriptionToSave: String , timeToSave: String , tagToSave: String ){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "TaskToDo", in: context)
        
        let taskToDoObject = NSManagedObject(entity: entity!, insertInto: context) as! TaskToDo
        taskToDoObject.titleOfYourTask = titleToSave
        taskToDoObject.descriptionOfYourTask = descriptionToSave
        taskToDoObject.tagOfYourTask = tagToSave
        taskToDoObject.endtimeOfYourTask = timeToSave
        
        print("hereeeeeee")
        
        do{
            try context.save()
            tasks.append(taskToDoObject)
            print("YOUR TASK IS SAVED")
        } catch {
            print("error")
        }
    }
    
    override func viewDidLoad() {
        print("LOAD!")
        super.viewDidLoad()
        guard let str = str else { return }
        print(str)
    }
    
    @IBAction func addTask(_ sender: UIBarButtonItem) {
       performSegue(withIdentifier: "addNewTask", sender: self)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "moreInformationAboutTask", sender: self)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return tasks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Task", for: indexPath) as? TaskTableViewCell else {
            fatalError("Can't init task cell")
        }
        
//        guard let task = getTask(by: indexPath) else {
//            fatalError("Can't get info for task cell")
//        }
        
        let task = tasks[indexPath.row]
        cell.todoTextLabel.text = task.titleOfYourTask
        cell.taskImage.image = UIImage(named: task.tagOfYourTask!)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 114
    }
    
    func getTask(by indexPath: IndexPath) -> Task? {
        guard let taskImage = UIImage(named: "co3") else { return nil }
        
        let task = tasks[indexPath.row]
        return Task(task: task.titleOfYourTask! , image: taskImage)
    }
 

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "moreInformationAboutTask" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                guard let infAboutVC = segue.destination as? InfomationAboutTaskViewController else {return}
                let task = tasks[indexPath.row]
                infAboutVC.titleOfTask = task.titleOfYourTask!
            }
        }
    }
}

class Task {
    var image: UIImage
    var text: String
    
    init(task text: String, image: UIImage) {
        self.text = text
        self.image = image
    }
    
}
