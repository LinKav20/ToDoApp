//
//  InfomationAboutTaskViewController.swift
//  ToDo
//
//  Created by Angelina on 22.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit

class InfomationAboutTaskViewController: UIViewController {

    @IBOutlet weak var decs: UITextView!
    @IBOutlet weak var edit: UIButton!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var changeYourTitle: UITextField!
    var titleBtn = "edit"
    
    var titleOfTask = ""
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func edit(_ sender: UIButton) {
        if titleBtn == "edit" {
            changeYourTitle.isHidden = false
            changeYourTitle.text = label.text
            label.text = ""
            decs.isEditable = true
            edit.setTitle("Done", for: .normal)
            titleBtn = "done"
        } else{
            changeYourTitle.isHidden = true
            label.text = changeYourTitle.text
            decs.isEditable = false
            edit.setTitle("Edit", for: .normal)
            titleBtn = "edit"
        }
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        changeYourTitle.text = titleOfTask
        label.text = titleOfTask
        label.numberOfLines = 0
    }

}
