//
//  TaskTableViewCell.swift
//  ToDo
//
//  Created by Angelina on 24.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    
    @IBOutlet weak var taskImage: UIImageView!
    @IBOutlet weak var todoTextLabel: UILabel!
    
    func setup(with task: Task) {
        self.taskImage.image = task.image
        self.todoTextLabel.text = task.text
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
