//
//  ContentViewController.swift
//  ToDo
//
//  Created by Angelina on 22.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit

class ContentViewController: UIViewController {

    @IBOutlet weak var mainInformation: UILabel!
    @IBOutlet weak var extraInformation: UILabel!
    @IBOutlet weak var pageControl: UIPageControl!
    
    var currentInformation = ""
    var currentExtraInformation = ""
    var currentPage = 0
    var maximumPages = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainInformation.text = currentInformation
        extraInformation.text = currentExtraInformation
        pageControl.numberOfPages = maximumPages
        pageControl.currentPage = currentPage
    }
    
    

}
