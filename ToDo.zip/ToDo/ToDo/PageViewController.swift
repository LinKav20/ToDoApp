//
//  PageViewController.swift
//  ToDo
//
//  Created by Angelina on 22.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit

class PageViewController: UIPageViewController {

    let mainInformation = [
        "HeadLine 1",
        "HeadLine 2",
        "HeadLine 3",
        "HeadLine 4",
        ""
    ]
    
    let extraInformation = [
        "Description 1",
        "Description 2",
        "Description 3",
        "Description 4",
        ""
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource = self
        
       if let contentViewController = showPresentation(0) {
        setViewControllers([contentViewController], direction: .forward, animated: true, completion: nil)
        }

    }
    
    func showPresentation(_ index: Int) -> ContentViewController?{
        guard index >= 0 else { return nil}
        guard index < mainInformation.count else {
            let userDefaults = UserDefaults.standard
            userDefaults.set(true, forKey: "presentationWasSeen")
            dismiss(animated: true, completion: nil)
            return nil
        }
        guard let contentViewController = storyboard?.instantiateViewController(withIdentifier: "ContentViewController") as? ContentViewController else { return nil }
        
        contentViewController.currentInformation = mainInformation[index]
        contentViewController.currentExtraInformation = extraInformation[index]
        contentViewController.currentPage = index
        contentViewController.maximumPages = mainInformation.count
        
        return contentViewController
    }
    

}


extension PageViewController: UIPageViewControllerDataSource{
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        var currentPage = (viewController as! ContentViewController).currentPage
        currentPage -= 1
        
        return showPresentation(currentPage)
        
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController?{
        
        var currentPage = (viewController as! ContentViewController).currentPage
        currentPage += 1
        
        return showPresentation(currentPage)
        
    }
}
