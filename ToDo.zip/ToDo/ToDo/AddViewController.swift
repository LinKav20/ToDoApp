//
//  AddViewController.swift
//  ToDo
//
//  Created by Angelina on 22.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController {

    @IBOutlet weak var titleTask: UITextView!
    @IBOutlet weak var descriptionTask: UITextView!
    @IBOutlet weak var color1: UIButton!
    @IBOutlet weak var color2: UIButton!
    @IBOutlet weak var color3: UIButton!
    @IBOutlet weak var color4: UIButton!
    @IBOutlet weak var color5: UIButton!
    @IBOutlet weak var color6: UIButton!
    @IBOutlet weak var color7: UIButton!
    @IBOutlet weak var endTask: UITextField!
    
    var tag: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func color1Selected(_ sender: UIButton) {
        color1.alpha = 1
        color2.alpha = 0.5
        color3.alpha = 0.5
        color4.alpha = 0.5
        color5.alpha = 0.5
        color6.alpha = 0.5
        color7.alpha = 0.5
        tag = "color1"
    }
    
    @IBAction func color2Selected(_ sender: UIButton) {
        color2.alpha = 1
        color1.alpha = 0.5
        color3.alpha = 0.5
        color4.alpha = 0.5
        color5.alpha = 0.5
        color6.alpha = 0.5
        color7.alpha = 0.5
        tag = "color2"
    }
    
    @IBAction func color3Selected(_ sender: UIButton) {
        color3.alpha = 1
        color1.alpha = 0.5
        color2.alpha = 0.5
        color4.alpha = 0.5
        color5.alpha = 0.5
        color6.alpha = 0.5
        color7.alpha = 0.5
        tag = "color3"
    }
    
    @IBAction func color4Selected(_ sender: UIButton) {
        color4.alpha = 1
        color2.alpha = 0.5
        color3.alpha = 0.5
        color1.alpha = 0.5
        color5.alpha = 0.5
        color6.alpha = 0.5
        color7.alpha = 0.5
        tag = "color4"
    }
    
    @IBAction func color5Selected(_ sender: UIButton) {
        color5.alpha = 1
        color1.alpha = 0.5
        color3.alpha = 0.5
        color4.alpha = 0.5
        color2.alpha = 0.5
        color6.alpha = 0.5
        color7.alpha = 0.5
        tag = "color5"
    }
    
    @IBAction func color6Selected(_ sender: UIButton) {
        color6.alpha = 1
        color1.alpha = 0.5
        color3.alpha = 0.5
        color4.alpha = 0.5
        color5.alpha = 0.5
        color2.alpha = 0.5
        color7.alpha = 0.5
        tag = "color6"
    }
    
    @IBAction func color7Selected(_ sender: UIButton) {
        color7.alpha = 1
        color2.alpha = 0.5
        color3.alpha = 0.5
        color4.alpha = 0.5
        color5.alpha = 0.5
        color6.alpha = 0.5
        color1.alpha = 0.5
        tag = "color7"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        guard let dest = segue.destination as? TableViewController else {return}
//        print("LOL")
//        dest.newTaskTag = tag
//        dest.newTaskDate = endTask.text!
//        dest.newTaskTitle = titleTask.text!
//        dest.newTaskDescription = descriptionTask.text!
    }
    
    @IBAction func addTask(_ sender: UIButton) {
        if titleTask.text.isEmpty == true || titleTask.text == "Enter title of your task" {alertWrong(); return}
        print("1")
        if descriptionTask.text.isEmpty == true || descriptionTask.text == "Enter short description of your task"{alertWrong(); return}
         print("2")
        if  tag == nil {alertWrong();return}
         print("3")
        if endTask.text?.isEmpty == true {alertWrong(); return}
         print("4")
        if correctFormat(str: endTask.text!) == false {alertWrong(); return}
        print("OLO")
        saveTask(titleToSave: titleTask.text!, descriptionToSave: descriptionTask.text!, timeToSave: endTask.text!, tagToSave: tag!)
        performSegue(withIdentifier: "returnToList", sender: self)
       
    }
    
    
    func saveTask( titleToSave: String, descriptionToSave: String , timeToSave: String , tagToSave: String ){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "TaskToDo", in: context)
        
        let taskToDoObject = NSManagedObject(entity: entity!, insertInto: context) as! TaskToDo
        taskToDoObject.titleOfYourTask = titleToSave
        taskToDoObject.descriptionOfYourTask = descriptionToSave
        taskToDoObject.tagOfYourTask = tagToSave
        taskToDoObject.endtimeOfYourTask = timeToSave
        
        print("hereeeeeee")
        
        do{
            try context.save()
            print("YOUR TASK IS SAVED")
        } catch {
            print("error")
        }
    }
    
    func alertWrong(){
        let alert = UIAlertController(title: "Something goes wrong!", message: "Please check all field on full and correct", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert,animated: true, completion: nil)
    }
    
    func correctFormat (str: String) -> Bool {
        guard str.count == 10 else {return false}
        return true
    }
    
   
}

