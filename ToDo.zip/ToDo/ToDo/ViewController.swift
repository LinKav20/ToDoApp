//
//  ViewController.swift
//  ToDo
//
//  Created by Angelina on 21.06.2019.
//  Copyright © 2019 Angelina. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var background: UIImageView!

    @IBOutlet weak var capitalname: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        capitalname.text = "JDI"
        initTap()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "todoMainSegue" {
            guard let dest = segue.destination as? TableViewController else {return}
            dest.str = capitalname.text
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        showPresentation()
    }
    
    func showPresentation() {
        let userDefaults = UserDefaults.standard
        let presentationWasSeen = userDefaults.bool(forKey: "presentationWasSeen")
        
        guard !presentationWasSeen else { return }
        
        if let pageViewController = storyboard?.instantiateViewController(withIdentifier: "PageViewController") as? PageViewController {
            present(pageViewController, animated: true, completion: nil)
        }
    }
    
    func initTap() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapFuncAction))
        tap.numberOfTapsRequired = 1
        self.view.addGestureRecognizer(tap)
    }

    @objc func tapFuncAction(){
        performSegue(withIdentifier: "todoMainSegue", sender: self)
   }
}

